﻿namespace OptionsOracle.Data {


    partial class AnalysisSet
    {
    }
}
