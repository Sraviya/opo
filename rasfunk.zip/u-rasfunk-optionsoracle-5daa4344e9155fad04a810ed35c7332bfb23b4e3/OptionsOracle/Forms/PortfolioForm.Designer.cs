namespace OptionsOracle.Forms
{
    partial class PortfolioForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PortfolioForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            this.openStrategiesGroupBox = new System.Windows.Forms.GroupBox();
            this.moveButton = new System.Windows.Forms.Button();
            this.deletePortfolioButton = new System.Windows.Forms.Button();
            this.addRowbutton = new System.Windows.Forms.Button();
            this.deleteRowbutton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.clearPositionButton = new System.Windows.Forms.Button();
            this.portfolioDataGridView = new System.Windows.Forms.DataGridView();
            this.portfolioIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioStockColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioStockLastPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioStockImpVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioStockHisVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioStartDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioEndDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioNetInvestmentColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioReturnIfUnchangeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioReturnIfUnchangePrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioCurrentReturnColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioCurrentReturnPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioReturnAtTargetColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioReturnAtTargetPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioMaxProfitPotentialColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioMaxProfitPotentialPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioMaxLossRiskColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioMaxLossRiskPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioLowerBreakevenColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioUpperBreakevenColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioBreakevenProbColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioBreakevenPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioInterestPaidColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioTotalDeltaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioTotalGammaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioTotalThetaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioTotalVegaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioExpectedReturnColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioExpectedReturnPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioOpoFileColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.portfolioTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.portfolioSet = new OptionsOracle.Data.PortfolioSet();
            this.summaryDataGridView = new System.Windows.Forms.DataGridView();
            this.summaryIsCreditColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.summaryIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.summaryCriteriaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.summaryTotalColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.summaryTotalPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.summaryTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.saveNotesButton = new System.Windows.Forms.Button();
            this.notesGroupBox = new System.Windows.Forms.GroupBox();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.portfolioTabControl = new System.Windows.Forms.TabControl();
            this.opoOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.openStrategiesGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.summaryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.summaryTableBindingSource)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.notesGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // openStrategiesGroupBox
            // 
            this.openStrategiesGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.openStrategiesGroupBox.Controls.Add(this.moveButton);
            this.openStrategiesGroupBox.Controls.Add(this.deletePortfolioButton);
            this.openStrategiesGroupBox.Controls.Add(this.addRowbutton);
            this.openStrategiesGroupBox.Controls.Add(this.deleteRowbutton);
            this.openStrategiesGroupBox.Controls.Add(this.updateButton);
            this.openStrategiesGroupBox.Controls.Add(this.clearPositionButton);
            this.openStrategiesGroupBox.Controls.Add(this.portfolioDataGridView);
            this.openStrategiesGroupBox.Location = new System.Drawing.Point(9, 35);
            this.openStrategiesGroupBox.Name = "openStrategiesGroupBox";
            this.openStrategiesGroupBox.Size = new System.Drawing.Size(843, 322);
            this.openStrategiesGroupBox.TabIndex = 0;
            this.openStrategiesGroupBox.TabStop = false;
            this.openStrategiesGroupBox.Text = "Open Strategies";
            // 
            // moveButton
            // 
            this.moveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.moveButton.Image = global::OptionsOracle.Properties.Resources.forward;
            this.moveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.moveButton.Location = new System.Drawing.Point(648, 262);
            this.moveButton.Name = "moveButton";
            this.moveButton.Size = new System.Drawing.Size(90, 50);
            this.moveButton.TabIndex = 33;
            this.moveButton.Text = "         Strategy\r\n         Table";
            this.moveButton.UseVisualStyleBackColor = true;
            this.moveButton.Click += new System.EventHandler(this.moveButton_Click);
            // 
            // deletePortfolioButton
            // 
            this.deletePortfolioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deletePortfolioButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deletePortfolioButton.Location = new System.Drawing.Point(102, 288);
            this.deletePortfolioButton.Name = "deletePortfolioButton";
            this.deletePortfolioButton.Size = new System.Drawing.Size(90, 24);
            this.deletePortfolioButton.TabIndex = 40;
            this.deletePortfolioButton.Text = "Delete Portfolio";
            this.deletePortfolioButton.UseVisualStyleBackColor = true;
            this.deletePortfolioButton.Click += new System.EventHandler(this.deletePortfolioButton_Click);
            // 
            // addRowbutton
            // 
            this.addRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addRowbutton.Location = new System.Drawing.Point(102, 262);
            this.addRowbutton.Name = "addRowbutton";
            this.addRowbutton.Size = new System.Drawing.Size(90, 24);
            this.addRowbutton.TabIndex = 25;
            this.addRowbutton.Text = "Add Strategy";
            this.addRowbutton.UseVisualStyleBackColor = true;
            this.addRowbutton.Click += new System.EventHandler(this.addRowbutton_Click);
            // 
            // deleteRowbutton
            // 
            this.deleteRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deleteRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deleteRowbutton.Location = new System.Drawing.Point(6, 262);
            this.deleteRowbutton.Name = "deleteRowbutton";
            this.deleteRowbutton.Size = new System.Drawing.Size(90, 24);
            this.deleteRowbutton.TabIndex = 24;
            this.deleteRowbutton.Text = "Delete Stategy";
            this.deleteRowbutton.UseVisualStyleBackColor = true;
            this.deleteRowbutton.Click += new System.EventHandler(this.deleteRowbutton_Click);
            // 
            // updateButton
            // 
            this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.updateButton.Image = ((System.Drawing.Image)(resources.GetObject("updateButton.Image")));
            this.updateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.updateButton.Location = new System.Drawing.Point(744, 262);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(90, 50);
            this.updateButton.TabIndex = 31;
            this.updateButton.Text = "         Update\r\n         All";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // clearPositionButton
            // 
            this.clearPositionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearPositionButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearPositionButton.Location = new System.Drawing.Point(6, 288);
            this.clearPositionButton.Name = "clearPositionButton";
            this.clearPositionButton.Size = new System.Drawing.Size(90, 24);
            this.clearPositionButton.TabIndex = 23;
            this.clearPositionButton.Text = "Delete All";
            this.clearPositionButton.UseVisualStyleBackColor = true;
            this.clearPositionButton.Click += new System.EventHandler(this.clearPositionButton_Click);
            // 
            // portfolioDataGridView
            // 
            this.portfolioDataGridView.AllowUserToAddRows = false;
            this.portfolioDataGridView.AllowUserToDeleteRows = false;
            this.portfolioDataGridView.AllowUserToOrderColumns = true;
            this.portfolioDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.portfolioDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.portfolioDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.portfolioDataGridView.ColumnHeadersHeight = 36;
            this.portfolioDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.portfolioDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.portfolioIndexColumn,
            this.portfolioStockColumn,
            this.portfolioNameColumn,
            this.portfolioStockLastPriceColumn,
            this.portfolioStockImpVolatilityColumn,
            this.portfolioStockHisVolatilityColumn,
            this.portfolioStartDateColumn,
            this.portfolioEndDateColumn,
            this.portfolioNetInvestmentColumn,
            this.portfolioReturnIfUnchangeColumn,
            this.portfolioReturnIfUnchangePrcColumn,
            this.portfolioCurrentReturnColumn,
            this.portfolioCurrentReturnPrcColumn,
            this.portfolioReturnAtTargetColumn,
            this.portfolioReturnAtTargetPrcColumn,
            this.portfolioMaxProfitPotentialColumn,
            this.portfolioMaxProfitPotentialPrcColumn,
            this.portfolioMaxLossRiskColumn,
            this.portfolioMaxLossRiskPrcColumn,
            this.portfolioLowerBreakevenColumn,
            this.portfolioUpperBreakevenColumn,
            this.portfolioBreakevenProbColumn,
            this.portfolioBreakevenPriceColumn,
            this.portfolioInterestPaidColumn,
            this.portfolioTotalDeltaColumn,
            this.portfolioTotalGammaColumn,
            this.portfolioTotalThetaColumn,
            this.portfolioTotalVegaColumn,
            this.portfolioExpectedReturnColumn,
            this.portfolioExpectedReturnPrcColumn,
            this.portfolioOpoFileColumn});
            this.portfolioDataGridView.DataSource = this.portfolioTableBindingSource;
            this.portfolioDataGridView.Location = new System.Drawing.Point(6, 19);
            this.portfolioDataGridView.Name = "portfolioDataGridView";
            this.portfolioDataGridView.RowHeadersVisible = false;
            this.portfolioDataGridView.RowHeadersWidth = 16;
            this.portfolioDataGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black;
            this.portfolioDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.portfolioDataGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Cornsilk;
            this.portfolioDataGridView.RowTemplate.Height = 20;
            this.portfolioDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.portfolioDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.portfolioDataGridView.Size = new System.Drawing.Size(828, 237);
            this.portfolioDataGridView.TabIndex = 2;
            this.portfolioDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.portfolioDataGridView_CellDoubleClick);
            this.portfolioDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.portfolioDataGridView_CellFormatting);
            this.portfolioDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.portfolioDataGridView_CellEndEdit);
            this.portfolioDataGridView.SelectionChanged += new System.EventHandler(this.portfolioDataGridView_SelectionChanged);
            // 
            // portfolioIndexColumn
            // 
            this.portfolioIndexColumn.DataPropertyName = "Index";
            this.portfolioIndexColumn.Frozen = true;
            this.portfolioIndexColumn.HeaderText = "Index";
            this.portfolioIndexColumn.Name = "portfolioIndexColumn";
            this.portfolioIndexColumn.ReadOnly = true;
            this.portfolioIndexColumn.Visible = false;
            this.portfolioIndexColumn.Width = 65;
            // 
            // portfolioStockColumn
            // 
            this.portfolioStockColumn.DataPropertyName = "Stock";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.portfolioStockColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.portfolioStockColumn.Frozen = true;
            this.portfolioStockColumn.HeaderText = "Stock";
            this.portfolioStockColumn.Name = "portfolioStockColumn";
            this.portfolioStockColumn.ReadOnly = true;
            this.portfolioStockColumn.Width = 65;
            // 
            // portfolioNameColumn
            // 
            this.portfolioNameColumn.DataPropertyName = "Name";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.portfolioNameColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.portfolioNameColumn.HeaderText = "Strategy Name";
            this.portfolioNameColumn.Name = "portfolioNameColumn";
            this.portfolioNameColumn.Width = 75;
            // 
            // portfolioStockLastPriceColumn
            // 
            this.portfolioStockLastPriceColumn.DataPropertyName = "StockLastPrice";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            this.portfolioStockLastPriceColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.portfolioStockLastPriceColumn.HeaderText = "Last Price";
            this.portfolioStockLastPriceColumn.Name = "portfolioStockLastPriceColumn";
            this.portfolioStockLastPriceColumn.ReadOnly = true;
            this.portfolioStockLastPriceColumn.Width = 65;
            // 
            // portfolioStockImpVolatilityColumn
            // 
            this.portfolioStockImpVolatilityColumn.DataPropertyName = "StockImpVolatility";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N2";
            this.portfolioStockImpVolatilityColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.portfolioStockImpVolatilityColumn.HeaderText = "Stock Implied Volatility";
            this.portfolioStockImpVolatilityColumn.Name = "portfolioStockImpVolatilityColumn";
            this.portfolioStockImpVolatilityColumn.ReadOnly = true;
            this.portfolioStockImpVolatilityColumn.Width = 75;
            // 
            // portfolioStockHisVolatilityColumn
            // 
            this.portfolioStockHisVolatilityColumn.DataPropertyName = "StockHisVolatility";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            this.portfolioStockHisVolatilityColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.portfolioStockHisVolatilityColumn.HeaderText = "Stock Historical Volatility";
            this.portfolioStockHisVolatilityColumn.Name = "portfolioStockHisVolatilityColumn";
            this.portfolioStockHisVolatilityColumn.ReadOnly = true;
            this.portfolioStockHisVolatilityColumn.Visible = false;
            this.portfolioStockHisVolatilityColumn.Width = 75;
            // 
            // portfolioStartDateColumn
            // 
            this.portfolioStartDateColumn.DataPropertyName = "StartDate";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "dd-MMM-yy";
            this.portfolioStartDateColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.portfolioStartDateColumn.HeaderText = "Start Date";
            this.portfolioStartDateColumn.Name = "portfolioStartDateColumn";
            this.portfolioStartDateColumn.ReadOnly = true;
            this.portfolioStartDateColumn.Width = 70;
            // 
            // portfolioEndDateColumn
            // 
            this.portfolioEndDateColumn.DataPropertyName = "EndDate";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "dd-MMM-yy";
            this.portfolioEndDateColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.portfolioEndDateColumn.HeaderText = "End Date";
            this.portfolioEndDateColumn.Name = "portfolioEndDateColumn";
            this.portfolioEndDateColumn.ReadOnly = true;
            this.portfolioEndDateColumn.Width = 70;
            // 
            // portfolioNetInvestmentColumn
            // 
            this.portfolioNetInvestmentColumn.DataPropertyName = "NetInvestment";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N2";
            this.portfolioNetInvestmentColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.portfolioNetInvestmentColumn.HeaderText = "Total Investment";
            this.portfolioNetInvestmentColumn.Name = "portfolioNetInvestmentColumn";
            this.portfolioNetInvestmentColumn.ReadOnly = true;
            this.portfolioNetInvestmentColumn.Width = 75;
            // 
            // portfolioReturnIfUnchangeColumn
            // 
            this.portfolioReturnIfUnchangeColumn.DataPropertyName = "ReturnIfUnchange";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            this.portfolioReturnIfUnchangeColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.portfolioReturnIfUnchangeColumn.HeaderText = "Return If Unchange";
            this.portfolioReturnIfUnchangeColumn.Name = "portfolioReturnIfUnchangeColumn";
            this.portfolioReturnIfUnchangeColumn.ReadOnly = true;
            this.portfolioReturnIfUnchangeColumn.Width = 75;
            // 
            // portfolioReturnIfUnchangePrcColumn
            // 
            this.portfolioReturnIfUnchangePrcColumn.DataPropertyName = "ReturnIfUnchangePrc";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "P2";
            this.portfolioReturnIfUnchangePrcColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.portfolioReturnIfUnchangePrcColumn.HeaderText = "Return If Unchange %";
            this.portfolioReturnIfUnchangePrcColumn.Name = "portfolioReturnIfUnchangePrcColumn";
            this.portfolioReturnIfUnchangePrcColumn.ReadOnly = true;
            this.portfolioReturnIfUnchangePrcColumn.Width = 75;
            // 
            // portfolioCurrentReturnColumn
            // 
            this.portfolioCurrentReturnColumn.DataPropertyName = "CurrentReturn";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "N2";
            this.portfolioCurrentReturnColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.portfolioCurrentReturnColumn.HeaderText = "Current Return";
            this.portfolioCurrentReturnColumn.Name = "portfolioCurrentReturnColumn";
            this.portfolioCurrentReturnColumn.ReadOnly = true;
            this.portfolioCurrentReturnColumn.Width = 75;
            // 
            // portfolioCurrentReturnPrcColumn
            // 
            this.portfolioCurrentReturnPrcColumn.DataPropertyName = "CurrentReturnPrc";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle13.Format = "P2";
            this.portfolioCurrentReturnPrcColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.portfolioCurrentReturnPrcColumn.HeaderText = "Current Return %";
            this.portfolioCurrentReturnPrcColumn.Name = "portfolioCurrentReturnPrcColumn";
            this.portfolioCurrentReturnPrcColumn.ReadOnly = true;
            this.portfolioCurrentReturnPrcColumn.Width = 75;
            // 
            // portfolioReturnAtTargetColumn
            // 
            this.portfolioReturnAtTargetColumn.DataPropertyName = "ReturnAtTarget";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "N2";
            this.portfolioReturnAtTargetColumn.DefaultCellStyle = dataGridViewCellStyle14;
            this.portfolioReturnAtTargetColumn.HeaderText = "Return At Target";
            this.portfolioReturnAtTargetColumn.Name = "portfolioReturnAtTargetColumn";
            this.portfolioReturnAtTargetColumn.ReadOnly = true;
            this.portfolioReturnAtTargetColumn.Visible = false;
            this.portfolioReturnAtTargetColumn.Width = 75;
            // 
            // portfolioReturnAtTargetPrcColumn
            // 
            this.portfolioReturnAtTargetPrcColumn.DataPropertyName = "ReturnAtTargetPrc";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "P2";
            this.portfolioReturnAtTargetPrcColumn.DefaultCellStyle = dataGridViewCellStyle15;
            this.portfolioReturnAtTargetPrcColumn.HeaderText = "Return At Target %";
            this.portfolioReturnAtTargetPrcColumn.Name = "portfolioReturnAtTargetPrcColumn";
            this.portfolioReturnAtTargetPrcColumn.ReadOnly = true;
            this.portfolioReturnAtTargetPrcColumn.Visible = false;
            this.portfolioReturnAtTargetPrcColumn.Width = 75;
            // 
            // portfolioMaxProfitPotentialColumn
            // 
            this.portfolioMaxProfitPotentialColumn.DataPropertyName = "MaxProfitPotential";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "N2";
            this.portfolioMaxProfitPotentialColumn.DefaultCellStyle = dataGridViewCellStyle16;
            this.portfolioMaxProfitPotentialColumn.HeaderText = "Max Profit Potential";
            this.portfolioMaxProfitPotentialColumn.Name = "portfolioMaxProfitPotentialColumn";
            this.portfolioMaxProfitPotentialColumn.ReadOnly = true;
            this.portfolioMaxProfitPotentialColumn.Width = 75;
            // 
            // portfolioMaxProfitPotentialPrcColumn
            // 
            this.portfolioMaxProfitPotentialPrcColumn.DataPropertyName = "MaxProfitPotentialPrc";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle17.Format = "P2";
            this.portfolioMaxProfitPotentialPrcColumn.DefaultCellStyle = dataGridViewCellStyle17;
            this.portfolioMaxProfitPotentialPrcColumn.HeaderText = "Max Profit Potential %";
            this.portfolioMaxProfitPotentialPrcColumn.Name = "portfolioMaxProfitPotentialPrcColumn";
            this.portfolioMaxProfitPotentialPrcColumn.ReadOnly = true;
            this.portfolioMaxProfitPotentialPrcColumn.Width = 75;
            // 
            // portfolioMaxLossRiskColumn
            // 
            this.portfolioMaxLossRiskColumn.DataPropertyName = "MaxLossRisk";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle18.Format = "N2";
            this.portfolioMaxLossRiskColumn.DefaultCellStyle = dataGridViewCellStyle18;
            this.portfolioMaxLossRiskColumn.HeaderText = "Max Loss Risk";
            this.portfolioMaxLossRiskColumn.Name = "portfolioMaxLossRiskColumn";
            this.portfolioMaxLossRiskColumn.ReadOnly = true;
            this.portfolioMaxLossRiskColumn.Width = 75;
            // 
            // portfolioMaxLossRiskPrcColumn
            // 
            this.portfolioMaxLossRiskPrcColumn.DataPropertyName = "MaxLossRiskPrc";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle19.Format = "P2";
            this.portfolioMaxLossRiskPrcColumn.DefaultCellStyle = dataGridViewCellStyle19;
            this.portfolioMaxLossRiskPrcColumn.HeaderText = "Max Loss Risk %";
            this.portfolioMaxLossRiskPrcColumn.Name = "portfolioMaxLossRiskPrcColumn";
            this.portfolioMaxLossRiskPrcColumn.ReadOnly = true;
            this.portfolioMaxLossRiskPrcColumn.Width = 75;
            // 
            // portfolioLowerBreakevenColumn
            // 
            this.portfolioLowerBreakevenColumn.DataPropertyName = "LowerBreakeven";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle20.Format = "P2";
            this.portfolioLowerBreakevenColumn.DefaultCellStyle = dataGridViewCellStyle20;
            this.portfolioLowerBreakevenColumn.HeaderText = "Lower Breakeven %";
            this.portfolioLowerBreakevenColumn.Name = "portfolioLowerBreakevenColumn";
            this.portfolioLowerBreakevenColumn.ReadOnly = true;
            this.portfolioLowerBreakevenColumn.Width = 80;
            // 
            // portfolioUpperBreakevenColumn
            // 
            this.portfolioUpperBreakevenColumn.DataPropertyName = "UpperBreakeven";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "P2";
            this.portfolioUpperBreakevenColumn.DefaultCellStyle = dataGridViewCellStyle21;
            this.portfolioUpperBreakevenColumn.HeaderText = "Upper Breakeven %";
            this.portfolioUpperBreakevenColumn.Name = "portfolioUpperBreakevenColumn";
            this.portfolioUpperBreakevenColumn.ReadOnly = true;
            this.portfolioUpperBreakevenColumn.Width = 80;
            // 
            // portfolioBreakevenProbColumn
            // 
            this.portfolioBreakevenProbColumn.DataPropertyName = "BreakevenProb";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle22.Format = "N2";
            this.portfolioBreakevenProbColumn.DefaultCellStyle = dataGridViewCellStyle22;
            this.portfolioBreakevenProbColumn.HeaderText = "Breakeven Prob";
            this.portfolioBreakevenProbColumn.Name = "portfolioBreakevenProbColumn";
            this.portfolioBreakevenProbColumn.ReadOnly = true;
            this.portfolioBreakevenProbColumn.Width = 75;
            // 
            // portfolioBreakevenPriceColumn
            // 
            this.portfolioBreakevenPriceColumn.DataPropertyName = "BreakevenPrice";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle23.Format = "N2";
            this.portfolioBreakevenPriceColumn.DefaultCellStyle = dataGridViewCellStyle23;
            this.portfolioBreakevenPriceColumn.HeaderText = "Breakeven Price";
            this.portfolioBreakevenPriceColumn.Name = "portfolioBreakevenPriceColumn";
            this.portfolioBreakevenPriceColumn.ReadOnly = true;
            this.portfolioBreakevenPriceColumn.Width = 75;
            // 
            // portfolioInterestPaidColumn
            // 
            this.portfolioInterestPaidColumn.DataPropertyName = "InterestPaid";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle24.Format = "N2";
            this.portfolioInterestPaidColumn.DefaultCellStyle = dataGridViewCellStyle24;
            this.portfolioInterestPaidColumn.HeaderText = "Interest Paid";
            this.portfolioInterestPaidColumn.Name = "portfolioInterestPaidColumn";
            this.portfolioInterestPaidColumn.ReadOnly = true;
            this.portfolioInterestPaidColumn.Width = 75;
            // 
            // portfolioTotalDeltaColumn
            // 
            this.portfolioTotalDeltaColumn.DataPropertyName = "TotalDelta";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle25.Format = "N2";
            this.portfolioTotalDeltaColumn.DefaultCellStyle = dataGridViewCellStyle25;
            this.portfolioTotalDeltaColumn.HeaderText = "Total Delta";
            this.portfolioTotalDeltaColumn.Name = "portfolioTotalDeltaColumn";
            this.portfolioTotalDeltaColumn.ReadOnly = true;
            this.portfolioTotalDeltaColumn.Width = 75;
            // 
            // portfolioTotalGammaColumn
            // 
            this.portfolioTotalGammaColumn.DataPropertyName = "TotalGamma";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle26.Format = "N2";
            this.portfolioTotalGammaColumn.DefaultCellStyle = dataGridViewCellStyle26;
            this.portfolioTotalGammaColumn.HeaderText = "Total Gamma";
            this.portfolioTotalGammaColumn.Name = "portfolioTotalGammaColumn";
            this.portfolioTotalGammaColumn.ReadOnly = true;
            this.portfolioTotalGammaColumn.Width = 75;
            // 
            // portfolioTotalThetaColumn
            // 
            this.portfolioTotalThetaColumn.DataPropertyName = "TotalTheta";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle27.Format = "N2";
            this.portfolioTotalThetaColumn.DefaultCellStyle = dataGridViewCellStyle27;
            this.portfolioTotalThetaColumn.HeaderText = "Total Theta";
            this.portfolioTotalThetaColumn.Name = "portfolioTotalThetaColumn";
            this.portfolioTotalThetaColumn.ReadOnly = true;
            this.portfolioTotalThetaColumn.Width = 75;
            // 
            // portfolioTotalVegaColumn
            // 
            this.portfolioTotalVegaColumn.DataPropertyName = "TotalVega";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle28.Format = "N2";
            this.portfolioTotalVegaColumn.DefaultCellStyle = dataGridViewCellStyle28;
            this.portfolioTotalVegaColumn.HeaderText = "Total Vega";
            this.portfolioTotalVegaColumn.Name = "portfolioTotalVegaColumn";
            this.portfolioTotalVegaColumn.ReadOnly = true;
            this.portfolioTotalVegaColumn.Width = 75;
            // 
            // portfolioExpectedReturnColumn
            // 
            this.portfolioExpectedReturnColumn.DataPropertyName = "ExpectedReturn";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle29.Format = "N2";
            this.portfolioExpectedReturnColumn.DefaultCellStyle = dataGridViewCellStyle29;
            this.portfolioExpectedReturnColumn.HeaderText = "Expected Return";
            this.portfolioExpectedReturnColumn.Name = "portfolioExpectedReturnColumn";
            this.portfolioExpectedReturnColumn.ReadOnly = true;
            this.portfolioExpectedReturnColumn.Width = 75;
            // 
            // portfolioExpectedReturnPrcColumn
            // 
            this.portfolioExpectedReturnPrcColumn.DataPropertyName = "ExpectedReturnPrc";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle30.Format = "P2";
            this.portfolioExpectedReturnPrcColumn.DefaultCellStyle = dataGridViewCellStyle30;
            this.portfolioExpectedReturnPrcColumn.HeaderText = "Expected Return %";
            this.portfolioExpectedReturnPrcColumn.Name = "portfolioExpectedReturnPrcColumn";
            this.portfolioExpectedReturnPrcColumn.ReadOnly = true;
            this.portfolioExpectedReturnPrcColumn.Width = 75;
            // 
            // portfolioOpoFileColumn
            // 
            this.portfolioOpoFileColumn.DataPropertyName = "OpoFile";
            this.portfolioOpoFileColumn.HeaderText = "OPO File";
            this.portfolioOpoFileColumn.Name = "portfolioOpoFileColumn";
            this.portfolioOpoFileColumn.ReadOnly = true;
            this.portfolioOpoFileColumn.Visible = false;
            this.portfolioOpoFileColumn.Width = 75;
            // 
            // portfolioTableBindingSource
            // 
            this.portfolioTableBindingSource.DataMember = "PortfolioTable";
            this.portfolioTableBindingSource.DataSource = this.portfolioSet;
            // 
            // portfolioSet
            // 
            this.portfolioSet.DataSetName = "PortfolioSet";
            this.portfolioSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // summaryDataGridView
            // 
            this.summaryDataGridView.AllowUserToAddRows = false;
            this.summaryDataGridView.AllowUserToDeleteRows = false;
            this.summaryDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.summaryDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.summaryDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.summaryDataGridView.ColumnHeadersHeight = 22;
            this.summaryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.summaryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.summaryIsCreditColumn,
            this.summaryIndexColumn,
            this.summaryCriteriaColumn,
            this.summaryTotalColumn,
            this.summaryTotalPrcColumn});
            this.summaryDataGridView.DataSource = this.summaryTableBindingSource;
            this.summaryDataGridView.Location = new System.Drawing.Point(10, 19);
            this.summaryDataGridView.Name = "summaryDataGridView";
            this.summaryDataGridView.ReadOnly = true;
            this.summaryDataGridView.RowHeadersVisible = false;
            this.summaryDataGridView.RowHeadersWidth = 16;
            this.summaryDataGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black;
            this.summaryDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.summaryDataGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Cornsilk;
            this.summaryDataGridView.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Black;
            this.summaryDataGridView.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Cornsilk;
            this.summaryDataGridView.RowTemplate.Height = 20;
            this.summaryDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.summaryDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.summaryDataGridView.Size = new System.Drawing.Size(353, 104);
            this.summaryDataGridView.TabIndex = 3;
            this.summaryDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.summaryDataGridView_CellFormatting);
            // 
            // summaryIsCreditColumn
            // 
            this.summaryIsCreditColumn.DataPropertyName = "IsCredit";
            this.summaryIsCreditColumn.HeaderText = "IsCredit";
            this.summaryIsCreditColumn.Name = "summaryIsCreditColumn";
            this.summaryIsCreditColumn.ReadOnly = true;
            this.summaryIsCreditColumn.Visible = false;
            // 
            // summaryIndexColumn
            // 
            this.summaryIndexColumn.DataPropertyName = "Index";
            this.summaryIndexColumn.HeaderText = "Index";
            this.summaryIndexColumn.Name = "summaryIndexColumn";
            this.summaryIndexColumn.ReadOnly = true;
            this.summaryIndexColumn.Visible = false;
            // 
            // summaryCriteriaColumn
            // 
            this.summaryCriteriaColumn.DataPropertyName = "Criteria";
            this.summaryCriteriaColumn.HeaderText = "Criteria";
            this.summaryCriteriaColumn.Name = "summaryCriteriaColumn";
            this.summaryCriteriaColumn.ReadOnly = true;
            this.summaryCriteriaColumn.Width = 200;
            // 
            // summaryTotalColumn
            // 
            this.summaryTotalColumn.DataPropertyName = "Total";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle32.Format = "N2";
            this.summaryTotalColumn.DefaultCellStyle = dataGridViewCellStyle32;
            this.summaryTotalColumn.HeaderText = "Total";
            this.summaryTotalColumn.Name = "summaryTotalColumn";
            this.summaryTotalColumn.ReadOnly = true;
            this.summaryTotalColumn.Width = 90;
            // 
            // summaryTotalPrcColumn
            // 
            this.summaryTotalPrcColumn.DataPropertyName = "TotalPrc";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle33.Format = "P2";
            this.summaryTotalPrcColumn.DefaultCellStyle = dataGridViewCellStyle33;
            this.summaryTotalPrcColumn.HeaderText = "%";
            this.summaryTotalPrcColumn.Name = "summaryTotalPrcColumn";
            this.summaryTotalPrcColumn.ReadOnly = true;
            this.summaryTotalPrcColumn.Width = 60;
            // 
            // summaryTableBindingSource
            // 
            this.summaryTableBindingSource.DataMember = "SummaryTable";
            this.summaryTableBindingSource.DataSource = this.portfolioSet;
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.WorkerSupportsCancellation = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 504);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(860, 22);
            this.statusStrip.TabIndex = 1;
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // notesTextBox
            // 
            this.notesTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.notesTextBox.Location = new System.Drawing.Point(6, 19);
            this.notesTextBox.Multiline = true;
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.notesTextBox.Size = new System.Drawing.Size(453, 74);
            this.notesTextBox.TabIndex = 34;
            // 
            // saveNotesButton
            // 
            this.saveNotesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.saveNotesButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveNotesButton.Location = new System.Drawing.Point(5, 99);
            this.saveNotesButton.Name = "saveNotesButton";
            this.saveNotesButton.Size = new System.Drawing.Size(90, 24);
            this.saveNotesButton.TabIndex = 35;
            this.saveNotesButton.Text = "Save Notes";
            this.saveNotesButton.UseVisualStyleBackColor = true;
            this.saveNotesButton.Click += new System.EventHandler(this.saveNotesButton_Click);
            // 
            // notesGroupBox
            // 
            this.notesGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.notesGroupBox.Controls.Add(this.notesTextBox);
            this.notesGroupBox.Controls.Add(this.saveNotesButton);
            this.notesGroupBox.Enabled = false;
            this.notesGroupBox.Location = new System.Drawing.Point(9, 363);
            this.notesGroupBox.Name = "notesGroupBox";
            this.notesGroupBox.Size = new System.Drawing.Size(465, 132);
            this.notesGroupBox.TabIndex = 38;
            this.notesGroupBox.TabStop = false;
            this.notesGroupBox.Text = "Strategy Description";
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.summaryGroupBox.Controls.Add(this.summaryDataGridView);
            this.summaryGroupBox.Enabled = false;
            this.summaryGroupBox.Location = new System.Drawing.Point(480, 363);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(371, 132);
            this.summaryGroupBox.TabIndex = 39;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Portfolio Summary";
            // 
            // portfolioTabControl
            // 
            this.portfolioTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.portfolioTabControl.Location = new System.Drawing.Point(9, 7);
            this.portfolioTabControl.Name = "portfolioTabControl";
            this.portfolioTabControl.SelectedIndex = 0;
            this.portfolioTabControl.Size = new System.Drawing.Size(843, 23);
            this.portfolioTabControl.TabIndex = 13;
            this.portfolioTabControl.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.portfolioTabControl_MouseDoubleClick);
            this.portfolioTabControl.SelectedIndexChanged += new System.EventHandler(this.portfolioTabControl_SelectedIndexChanged);
            // 
            // opoOpenFileDialog
            // 
            this.opoOpenFileDialog.Filter = "opo files (*.opo)|*.opo|All files (*.*)|*.*";
            this.opoOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opoPath;
            // 
            // PortfolioForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 526);
            this.Controls.Add(this.portfolioTabControl);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.notesGroupBox);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.openStrategiesGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PortfolioForm";
            this.Text = "Portfolio Manager";
            this.Load += new System.EventHandler(this.PortfolioForm_Load);
            this.openStrategiesGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.portfolioDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.summaryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.summaryTableBindingSource)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.notesGroupBox.ResumeLayout(false);
            this.notesGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox openStrategiesGroupBox;
        private System.Windows.Forms.DataGridView portfolioDataGridView;
        private System.Windows.Forms.BindingSource portfolioTableBindingSource;
        private OptionsOracle.Data.PortfolioSet portfolioSet;
        private System.Windows.Forms.Button addRowbutton;
        private System.Windows.Forms.Button deleteRowbutton;
        private System.Windows.Forms.Button clearPositionButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button moveButton;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.DataGridView summaryDataGridView;
        private System.Windows.Forms.BindingSource summaryTableBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn summaryIndexColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn summaryCriteriaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn summaryTotalColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn summaryTotalPrcColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn summaryIsCreditColumn;
        private System.Windows.Forms.Button saveNotesButton;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.GroupBox notesGroupBox;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Button deletePortfolioButton;
        private System.Windows.Forms.TabControl portfolioTabControl;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioIndexColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioStockColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioStockLastPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioStockImpVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioStockHisVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioStartDateColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioEndDateColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioNetInvestmentColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioReturnIfUnchangeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioReturnIfUnchangePrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioCurrentReturnColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioCurrentReturnPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioReturnAtTargetColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioReturnAtTargetPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioMaxProfitPotentialColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioMaxProfitPotentialPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioMaxLossRiskColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioMaxLossRiskPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioLowerBreakevenColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioUpperBreakevenColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioBreakevenProbColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioBreakevenPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioInterestPaidColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioTotalDeltaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioTotalGammaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioTotalThetaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioTotalVegaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioExpectedReturnColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioExpectedReturnPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn portfolioOpoFileColumn;
        private System.Windows.Forms.OpenFileDialog opoOpenFileDialog;
    }
}